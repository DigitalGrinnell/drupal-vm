<?php

/* {# inline_template_start #}<table class='issue-info-table'>
<tr><td class='issue-thumbnail'>{{ field_thumbnail }}</td><td class='issue-title-and-description' style='vertical-align:top;'><p class='issue-title'>{{ title }}</p><p class='issue-description'>{{ body }}</p></td></tr>
</table> */
class __TwigTemplate_a4ea7bb3c5b5c4b226ead37b21dd07e4b55f5d9e87bd93e5738aef6b3a9f32cd extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $tags = array();
        $filters = array();
        $functions = array();

        try {
            $this->env->getExtension('Twig_Extension_Sandbox')->checkSecurity(
                array(),
                array(),
                array()
            );
        } catch (Twig_Sandbox_SecurityError $e) {
            $e->setTemplateName($this->getTemplateName());

            if ($e instanceof Twig_Sandbox_SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof Twig_Sandbox_SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof Twig_Sandbox_SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

        // line 1
        echo "<table class='issue-info-table'>
<tr><td class='issue-thumbnail'>";
        // line 2
        echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, ($context["field_thumbnail"] ?? null), "html", null, true));
        echo "</td><td class='issue-title-and-description' style='vertical-align:top;'><p class='issue-title'>";
        echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, ($context["title"] ?? null), "html", null, true));
        echo "</p><p class='issue-description'>";
        echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, ($context["body"] ?? null), "html", null, true));
        echo "</p></td></tr>
</table>";
    }

    public function getTemplateName()
    {
        return "{# inline_template_start #}<table class='issue-info-table'>
<tr><td class='issue-thumbnail'>{{ field_thumbnail }}</td><td class='issue-title-and-description' style='vertical-align:top;'><p class='issue-title'>{{ title }}</p><p class='issue-description'>{{ body }}</p></td></tr>
</table>";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  48 => 2,  45 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "{# inline_template_start #}<table class='issue-info-table'>
<tr><td class='issue-thumbnail'>{{ field_thumbnail }}</td><td class='issue-title-and-description' style='vertical-align:top;'><p class='issue-title'>{{ title }}</p><p class='issue-description'>{{ body }}</p></td></tr>
</table>", "");
    }
}
